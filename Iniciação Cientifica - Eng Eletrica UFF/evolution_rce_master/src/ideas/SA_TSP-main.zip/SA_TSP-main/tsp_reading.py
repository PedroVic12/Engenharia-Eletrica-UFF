from numpy import loadtxt
def tsp_reading(file_name):
    data = loadtxt(file_name);
    return(data);